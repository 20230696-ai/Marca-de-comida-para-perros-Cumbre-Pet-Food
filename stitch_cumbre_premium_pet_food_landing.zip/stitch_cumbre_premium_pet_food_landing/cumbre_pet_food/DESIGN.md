---
name: Cumbre Pet Food
colors:
  surface: '#fcf9f8'
  surface-dim: '#dcd9d9'
  surface-bright: '#fcf9f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3f2'
  surface-container: '#f0eded'
  surface-container-high: '#eae7e7'
  surface-container-highest: '#e5e2e1'
  on-surface: '#1b1c1c'
  on-surface-variant: '#414944'
  inverse-surface: '#303030'
  inverse-on-surface: '#f3f0ef'
  outline: '#717973'
  outline-variant: '#c0c9c2'
  surface-tint: '#3a6753'
  primary: '#023625'
  on-primary: '#ffffff'
  primary-container: '#1f4d3a'
  on-primary-container: '#8dbda4'
  inverse-primary: '#a1d1b8'
  secondary: '#775a19'
  on-secondary: '#ffffff'
  secondary-container: '#fdd487'
  on-secondary-container: '#785a19'
  tertiary: '#163423'
  on-tertiary: '#ffffff'
  tertiary-container: '#2d4b38'
  on-tertiary-container: '#99baa2'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#bceed3'
  primary-fixed-dim: '#a1d1b8'
  on-primary-fixed: '#002114'
  on-primary-fixed-variant: '#214f3c'
  secondary-fixed: '#ffdea4'
  secondary-fixed-dim: '#e8c176'
  on-secondary-fixed: '#261900'
  on-secondary-fixed-variant: '#5d4200'
  tertiary-fixed: '#c8ebd1'
  tertiary-fixed-dim: '#adcfb6'
  on-tertiary-fixed: '#022111'
  on-tertiary-fixed-variant: '#2f4d3a'
  background: '#fcf9f8'
  on-background: '#1b1c1c'
  surface-variant: '#e5e2e1'
typography:
  headline-xl:
    fontFamily: Playfair Display
    fontSize: 56px
    fontWeight: '600'
    lineHeight: 64px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Playfair Display
    fontSize: 36px
    fontWeight: '600'
    lineHeight: 44px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 40px
    fontWeight: '600'
    lineHeight: 48px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Playfair Display
    fontSize: 28px
    fontWeight: '500'
    lineHeight: 36px
  headline-sm:
    fontFamily: Playfair Display
    fontSize: 22px
    fontWeight: '500'
    lineHeight: 30px
  subheading:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '500'
    lineHeight: 28px
    letterSpacing: 0.01em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.08em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.12em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 3rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 2rem
  space-xl: 3.5rem
---

## Brand & Style

This design system expresses the distinction of an artisanal culinary house dedicated to canine nutrition. Balancing high-gastronomy cues with biological integrity, the visual language moves away from typical clinical or playful pet industry motifs, leaning into the quiet authority of heritage epicurean brands.

The target audience consists of discerning pet owners who view their dogs as family members and prioritize holistic wellness, organic sourcing, and ethical gastronomy. 

Key attributes:
- **Sophisticated & Restrained:** Generous editorial whitespace, measured proportions, and deliberate compositions.
- **Warm & Trustworthy:** Tactile, organic baseline surfaces that eschew clinical starkness in favor of artisanal warmth.
- **Culinary Heritage:** High-contrast serif headlines paired with precise geometric sans-serif details, reminiscent of estate wines and Michelin-starred menus.
- **Subtle Elevation:** Whispers of metallic gold detailing and geometric peak abstractions inspired by alpine provenance.

## Colors

The palette grounds the brand in natural alpine heritage and artisanal dining:

- **Primary (`#1F4D3A`)**: Deep emerald green. Used for dominant brand statements, primary interactive elements, and structural containers.
- **Secondary / Accent (`#C9A45C`)**: Soft warm gold. Reserved for fine line embellishments, status insignias, certification crests, and subtle hover interactions.
- **Tertiary (`#12301F`)**: Deepest forest green. Deployed for high-contrast evening modules, editorial footers, and sensory focus sections.
- **Neutral / Text (`#222222`)**: Rich charcoal, preventing harsh pure-black contrast while preserving legibility across all screens.
- **Surface Roles**:
  - Base Canvas: Warm Ivory (`#FAF6EE`).
  - Elevated Container / Secondary Canvas: Light Beige (`#EFE7D8`).
  - Inverted Text on Dark Green: Warm Ivory (`#FAF6EE`).

Avoid bright saturated utility colors. Semantic states should be tempered: an olive-tinted green for positive verification and a muted terracotta red for errors.

## Typography

The typographical pairing unites the classic grace of editorial print with modern screen clarity:

- **Headlines (Playfair Display)**: Imbues the brand with heritage, sophistication, and a boutique culinary voice. It is used sparingly for section milestones, recipe titles, and ingredient storytelling.
- **Body & Functional Text (Plus Jakarta Sans)**: Ensures contemporary, comfortable legibility for dense nutritional profiles, preparation steps, and subscription management.
- **Uppercase Labels**: Category headers, ingredient markers, and metadata tokens utilize `label-md` and `label-sm` set in all-caps with generous letter-spacing to evoke classic luxury packaging typography.

## Layout & Spacing

The layout philosophy follows a disciplined, architectural grid marked by unhurried pacing:

- **Desktop (1200px+)**: 12-column layout with 24px gutters and 48px outer canvas margins. Maximum readable container width caps at 1280px to protect editorial line lengths.
- **Tablet (768px - 1199px)**: 8-column layout with 20px gutters and 32px margins. Two-column cards collapse to single- or dual-row arrangements.
- **Mobile (< 768px)**: 4-column layout with 16px gutters and 20px margins. Full-width edge bleeding is permitted only for dark contrast sections and hero imagery.

Generous vertical padding (`space-xl` and higher) separates distinct recipe tiers and certification badges, resisting the dense, discount-driven clutter typical of commercial e-commerce.

## Elevation & Depth

To maintain an organic, tactile aesthetic, this design system does not use heavy, synthetic drop shadows or glossy surfaces.

- **Tonal Layering**: Depth is achieved primarily through surface juxtaposition—warm ivory (`#FAF6EE`) sits as the primary plane, layered with soft beige cards (`#EFE7D8`) and deeply grounded contrast blocks (`#12301F`).
- **Hairline Outlines**: Elements establish boundaries via delicate 1px borders in subdued gold (`rgba(201, 164, 92, 0.35)`) or soft tinted beige (`rgba(31, 77, 58, 0.08)`).
- **Subtle Ambient Lift**: Where interaction demands tactile elevation (e.g., floating cart drawer, modal recipe inspect), use an ultra-diffused, ambient shadow: `0 12px 32px -4px rgba(18, 48, 31, 0.06)`. The green undertone anchors the shadow naturally to the palette.

## Shapes

The design uses soft, tailored geometry (`roundedness: 1`). 

- Corners across cards, input containers, and structural sections feature a disciplined 4px radius (`0.25rem`), conveying architectural craftsmanship and heritage packaging rather than casual playfulness.
- Feature tags and ingredient origin indicators utilize strict rectangular forms or delicate 2px softenings.
- Circular geometry is strictly reserved for circular seals, batch origin badges, and avatar frames.

## Components

### Buttons
- **Primary**: Deep emerald green background (`#1F4D3A`), warm ivory text (`#FAF6EE`), 4px border radius. Padding: `14px 28px`. Hover state: Subtle gold border transition (`#C9A45C`) with a darkened background (`#12301F`).
- **Secondary / Outline**: Transparent background, 1px solid soft gold border (`#C9A45C`), deep green text (`#1F4D3A`). Hover state: Background fills with light beige (`#EFE7D8`).
- **Dark Inverted**: Light beige or soft gold background with dark green text (`#12301F`), applied inside inverted dark sections.

### Cards
- **Gourmet Recipe Card**: Light beige background (`#EFE7D8`), 1px perimeter border in `rgba(201, 164, 92, 0.25)`. Image occupies top tier with an inset margin. Inner padding: `24px`. Displays recipe name in Playfair Display, followed by protein origin markers in spaced uppercase labels.
- **Nutritional Feature Card**: Warm ivory surface floating on a light beige canvas, defined by hairline emerald borders (`rgba(31, 77, 58, 0.1)`).

### Form Controls & Inputs
- **Text Inputs**: Crisp ivory surface, 1px border using muted emerald grey (`rgba(31, 77, 58, 0.2)`). Focus state illuminates with a 1px soft gold highlight (`#C9A45C`) without harsh browser glow. Text in rich charcoal (`#222222`).
- **Checkboxes & Radios**: Custom square or circle indicators in 1px gold border. Active state fills with `#1F4D3A` featuring an ivory check or dot.

### Chips & Badges
- **Ingredient & Benefit Chips**: Monochromatic or dual-tone pill shapes with 1px border. Background: transparent or `#EFE7D8`. Text: `label-sm` in `#1F4D3A`. Used for attributes like *"Corte Entero"*, *"Sin Granos"*, or *"Pato Silvestre"*.

### Editorial Peak Divider
- A custom horizontal rule featuring an ultra-fine 1px gold line interrupted centrally by an abstract geometric mountain peak emblem (a delicate 12px gold chevron). Used to divide narrative sections from catalog views.